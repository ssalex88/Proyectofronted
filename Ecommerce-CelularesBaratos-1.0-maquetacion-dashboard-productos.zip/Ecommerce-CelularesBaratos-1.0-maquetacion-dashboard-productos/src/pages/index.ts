export * from './HomePage';
export * from './CellPhonesPage';
export * from './AboutPage';
export * from './CellPhonePage';
export * from './LoginPage';
export * from './RegisterPage';
export * from './OrdersUserPage';
export * from './CheckoutPage';
export * from './ThankyouPage';
export * from './OrderUserPage';

/* ********************************** */
/*           DASHBOARD PAGES          */
/* ********************************** */
export * from './dashboard/DashboardProductsPage';
