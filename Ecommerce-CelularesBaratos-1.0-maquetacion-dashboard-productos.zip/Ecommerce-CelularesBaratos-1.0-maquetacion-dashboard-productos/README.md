# React + TypeScript + Vite

Ecommerce de celulares desarrollado en React 


## Herramientas utilizadas:
- React
- Supabase
- Tanstack Query
- Zustand
- React Hook Form
- Zod 